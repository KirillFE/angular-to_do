// Angular
import '@angular/platform-browser';
import '@angular/platform-browser-dynamic';
import '@angular/core';
import '@angular/common';
import '@angular/http';
import '@angular/router';
// RxJS
import 'rxjs';
// Other vendors for example jQuery, Lodash or Bootstrap
// You can import js, ts, css, sass, ...
import * as $ from 'jquery';
window["jQuery"] = $;
window["$"] = $;
import 'jsrender';
//import '../node_modules/syncfusion-javascript/Content/ej/web/material/ej.web.all.min.css';
//import '../node_modules/bootstrap/dist/css/bootstrap.min.css';

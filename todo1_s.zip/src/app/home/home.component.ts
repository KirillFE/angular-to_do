import { Component } from '@angular/core';
import * as Todolist from '../todolist/todolist.component';

@Component({
    selector: 'app',
    templateUrl: './home.component.html',
})
export class HomeComponent {

}
